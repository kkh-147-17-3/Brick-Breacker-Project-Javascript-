import Button from "./Button.js";

export default class Help extends Button{
    constructor(){
      super("help");
    }
}