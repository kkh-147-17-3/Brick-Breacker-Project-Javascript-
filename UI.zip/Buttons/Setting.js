import Button from "./Button.js";


export default class Setting extends Button{
    constructor(){
      super("setting");
    }
}